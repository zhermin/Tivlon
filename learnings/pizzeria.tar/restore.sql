--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.3
-- Dumped by pg_dump version 12.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "Pizzeria";
--
-- Name: Pizzeria; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "Pizzeria" WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'English_United States.1252' LC_CTYPE = 'English_United States.1252';


ALTER DATABASE "Pizzeria" OWNER TO postgres;

\connect "Pizzeria"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: pizzas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pizzas (
    pizza character varying(50) NOT NULL
);


ALTER TABLE public.pizzas OWNER TO postgres;

--
-- Name: ratings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ratings (
    rname character varying(50),
    rating integer,
    restaurant_id integer
);


ALTER TABLE public.ratings OWNER TO postgres;

--
-- Name: ratings_central; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ratings_central (
    rname character varying(50),
    rating integer,
    restaurant_id integer
);


ALTER TABLE public.ratings_central OWNER TO postgres;

--
-- Name: restaurants; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.restaurants (
    rname character varying(50) NOT NULL,
    area character varying(10),
    restaurant_id integer
);


ALTER TABLE public.restaurants OWNER TO postgres;

--
-- Name: sells; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sells (
    rname character varying(50) NOT NULL,
    pizza character varying(50) NOT NULL,
    price integer
);


ALTER TABLE public.sells OWNER TO postgres;

--
-- Data for Name: pizzas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pizzas (pizza) FROM stdin;
\.
COPY public.pizzas (pizza) FROM '$$PATH$$/2837.dat';

--
-- Data for Name: ratings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ratings (rname, rating, restaurant_id) FROM stdin;
\.
COPY public.ratings (rname, rating, restaurant_id) FROM '$$PATH$$/2840.dat';

--
-- Data for Name: ratings_central; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ratings_central (rname, rating, restaurant_id) FROM stdin;
\.
COPY public.ratings_central (rname, rating, restaurant_id) FROM '$$PATH$$/2841.dat';

--
-- Data for Name: restaurants; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.restaurants (rname, area, restaurant_id) FROM stdin;
\.
COPY public.restaurants (rname, area, restaurant_id) FROM '$$PATH$$/2838.dat';

--
-- Data for Name: sells; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sells (rname, pizza, price) FROM stdin;
\.
COPY public.sells (rname, pizza, price) FROM '$$PATH$$/2839.dat';

--
-- Name: pizzas pizzas_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pizzas
    ADD CONSTRAINT pizzas_pkey PRIMARY KEY (pizza);


--
-- Name: restaurants restaurants_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.restaurants
    ADD CONSTRAINT restaurants_pkey PRIMARY KEY (rname);


--
-- Name: sells sells_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sells
    ADD CONSTRAINT sells_pkey PRIMARY KEY (rname, pizza);


--
-- Name: ratings_central ratings_central_rname_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ratings_central
    ADD CONSTRAINT ratings_central_rname_fkey FOREIGN KEY (rname) REFERENCES public.restaurants(rname);


--
-- Name: ratings ratings_rname_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ratings
    ADD CONSTRAINT ratings_rname_fkey FOREIGN KEY (rname) REFERENCES public.restaurants(rname);


--
-- Name: sells sells_pizza_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sells
    ADD CONSTRAINT sells_pizza_fkey FOREIGN KEY (pizza) REFERENCES public.pizzas(pizza);


--
-- Name: sells sells_rname_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sells
    ADD CONSTRAINT sells_rname_fkey FOREIGN KEY (rname) REFERENCES public.restaurants(rname);


--
-- PostgreSQL database dump complete
--

